# Stone Paper Scissors

A small Flask website. Python handles the game logic (the computer's move,
who wins, and the score) on the server; the browser just shows the result.

## Run it

```bash
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## How it works

- `app.py` — Flask server: routes, the win/lose/tie logic, and the score
  kept in the session.
- `templates/index.html` — the page structure.
- `static/style.css` — the look (felt table, paper game pieces).
- `static/script.js` — sends your click to `/play`, gets the result back,
  and updates the page.

Score resets when you click "Start over," or naturally when your browser
session ends.
