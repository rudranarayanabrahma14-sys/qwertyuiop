const ICONS = {
  rock: `<path d="M20 55 Q14 32 40 22 Q60 9 79 27 Q91 40 82 59 Q77 79 54 83 Q27 86 17 68 Q11 59 20 55 Z"/>`,
  paper: `<path d="M24 10 H64 L80 26 V90 H24 Z"/><path d="M64 10 V26 H80 Z"/>`,
  scissors: `<circle cx="24" cy="76" r="11"/><circle cx="24" cy="24" r="11"/>
             <line x1="32" y1="31" x2="88" y2="87"/><line x1="32" y1="69" x2="88" y2="13"/>`,
};

const LABEL = { rock: "Stone", paper: "Paper", scissors: "Scissors" };
const BEATS_PHRASE = {
  "rock-scissors": "Stone crushes Scissors",
  "paper-rock": "Paper covers Stone",
  "scissors-paper": "Scissors cut Paper",
};

const pieces = document.querySelectorAll(".piece");
const youIcon = document.getElementById("you-icon");
const cpuIcon = document.getElementById("cpu-icon");
const verdictEl = document.getElementById("verdict");
const resetBtn = document.getElementById("reset-btn");

function setIcon(el, choice, outcomeClass) {
  el.innerHTML = `<svg viewBox="0 0 100 100">${ICONS[choice]}</svg>`;
  el.classList.remove("win", "lose", "reveal");
  void el.offsetWidth; // restart animation
  el.classList.add("reveal");
  if (outcomeClass) el.classList.add(outcomeClass);
}

function verdictText(result, player, computer) {
  if (result === "tie") return `Tie — you both threw ${LABEL[player]}`;
  const winner = result === "win" ? player : computer;
  const loser = result === "win" ? computer : player;
  const phrase = BEATS_PHRASE[`${winner}-${loser}`];
  return result === "win" ? `You win — ${phrase}` : `You lose — ${phrase}`;
}

async function play(choice) {
  pieces.forEach((p) => (p.disabled = true));

  let data;
  try {
    const res = await fetch("/play", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ choice }),
    });
    data = await res.json();
  } catch (err) {
    verdictEl.textContent = "Couldn't reach the server — try again.";
    pieces.forEach((p) => (p.disabled = false));
    return;
  }

  setIcon(youIcon, data.player, data.result === "win" ? "win" : data.result === "lose" ? "lose" : null);
  setIcon(cpuIcon, data.computer, data.result === "lose" ? "win" : data.result === "win" ? "lose" : null);
  verdictEl.textContent = verdictText(data.result, data.player, data.computer);

  document.getElementById("wins").textContent = data.scores.wins;
  document.getElementById("ties").textContent = data.scores.ties;
  document.getElementById("losses").textContent = data.scores.losses;

  pieces.forEach((p) => {
    p.classList.toggle("is-selected", p.dataset.choice === choice);
    p.disabled = false;
  });
}

pieces.forEach((btn) => {
  btn.addEventListener("click", () => play(btn.dataset.choice));
});

resetBtn.addEventListener("click", async () => {
  const res = await fetch("/reset", { method: "POST" });
  const data = await res.json();
  document.getElementById("wins").textContent = data.scores.wins;
  document.getElementById("ties").textContent = data.scores.ties;
  document.getElementById("losses").textContent = data.scores.losses;
  verdictEl.textContent = "Make your move";
  youIcon.innerHTML = '<span class="placeholder">?</span>';
  cpuIcon.innerHTML = '<span class="placeholder">?</span>';
  youIcon.className = "face-icon";
  cpuIcon.className = "face-icon";
  pieces.forEach((p) => p.classList.remove("is-selected"));
});
