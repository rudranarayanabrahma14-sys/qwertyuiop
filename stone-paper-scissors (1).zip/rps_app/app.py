import random
from flask import Flask, render_template, request, jsonify, session

app = Flask(__name__)
app.secret_key = "dev-secret-key-change-me"  # only matters if you deploy this for real

CHOICES = ["rock", "paper", "scissors"]

# What beats what: key beats value
BEATS = {
    "rock": "scissors",
    "paper": "rock",
    "scissors": "paper",
}


def judge(player, computer):
    """Return 'win', 'lose', or 'tie' from the player's point of view."""
    if player == computer:
        return "tie"
    if BEATS[player] == computer:
        return "win"
    return "lose"


def get_scores():
    session.setdefault("wins", 0)
    session.setdefault("losses", 0)
    session.setdefault("ties", 0)
    return {
        "wins": session["wins"],
        "losses": session["losses"],
        "ties": session["ties"],
    }


@app.route("/")
def index():
    scores = get_scores()
    return render_template("index.html", scores=scores)


@app.route("/play", methods=["POST"])
def play():
    data = request.get_json(silent=True) or {}
    player_choice = data.get("choice")

    if player_choice not in CHOICES:
        return jsonify({"error": "Invalid choice"}), 400

    computer_choice = random.choice(CHOICES)
    result = judge(player_choice, computer_choice)

    scores = get_scores()
    if result == "win":
        session["wins"] = scores["wins"] + 1
    elif result == "lose":
        session["losses"] = scores["losses"] + 1
    else:
        session["ties"] = scores["ties"] + 1

    return jsonify(
        {
            "player": player_choice,
            "computer": computer_choice,
            "result": result,
            "scores": get_scores(),
        }
    )


@app.route("/reset", methods=["POST"])
def reset():
    session["wins"] = 0
    session["losses"] = 0
    session["ties"] = 0
    return jsonify({"scores": get_scores()})


if __name__ == "__main__":
    app.run(debug=True)
